package com.onlyjavatech.springbootproject.repository;

import org.springframework.data.repository.CrudRepository;

import com.onlyjavatech.springbootproject.bean.Subject;

public interface SubjectRepository extends CrudRepository<Subject,String> {

}
